# MR.GIIBYE FITNESS PWA — Version 1

Included: responsive black/white dashboard, working daily checklist (add/complete/delete/reset), local meal photo preview, reflection checklist, reminder suggestions, optional local display name, PWA manifest and service worker.

## Publish using Android
1. Open github.com in Chrome and sign in.
2. Create a new repository named `mr-giibye-fitness` (Public).
3. Choose Add file → Upload files.
4. Upload every file in this folder, including both PNG icons. Commit changes.
5. Open repository Settings → Pages.
6. Under Build and deployment choose Deploy from a branch; branch `main`, folder `/ (root)`, then Save.
7. Wait for the Pages URL shown there.

Notes: the meal image is preview-only; no AI food recognition, nutrition calculation, or upload. Reminders are suggestions, not notifications. Checklist/profile are stored locally in that browser/device. PWA install requires HTTPS and a compatible browser. This is a prototype, not medical advice.
